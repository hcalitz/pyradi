Modtran utility
******************

.. include global.rst


Overview
----------

.. automodule:: pyradi.rymodtran

Module classes
------------------


.. autofunction:: pyradi.rymodtran.fixHeaders	

.. autofunction:: pyradi.rymodtran.loadtape7	

.. autofunction:: pyradi.rymodtran.fixHeadersList	

.. autofunction:: pyradi.rymodtran.savetape7data	


	