Colour coordinates
******************

.. include global.rst


Overview
----------

.. automodule:: pyradi.rychroma
	
Module functions
------------------

.. autofunction:: pyradi.rychroma.chromaticityforSpectralL

