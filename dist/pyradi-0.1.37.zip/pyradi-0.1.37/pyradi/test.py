import numpy as np
import pyradi.ryplot as ryplot
from matplotlib import cm

def myFunc(x,y):
  scale = np.sqrt(np.exp(-(x**2 +y**2)))
  return np.sin(2 * x) * np.cos(4 * y) * scale

x = np.linspace(-2, 2, 101)
y = np.linspace(-2, 2, 101)
varx, vary = np.meshgrid(x, y)
zdata = myFunc(varx.flatten(), vary.flatten()).reshape(varx.shape)

print(zdata.shape)

p = ryplot.Plotter(1,2,2,figsize=(18,14))
p.mesh3D(1, varx, vary, zdata, ptitle='Title', xlabel='x', ylabel='y', zlabel='z',
  rstride=3, cstride=3, linewidth= 1, maxNX=5, maxNY=5, maxNZ=0,
  drawGrid=True, cbarshow=True, cmap=None)
p.mesh3D(2, varx, vary, zdata, ptitle='Title', xlabel='x', ylabel='y', zlabel='z',
  rstride=3, cstride=3, linewidth= 0.3, maxNX=5, maxNY=5, maxNZ=0,
  drawGrid=True, cbarshow=True, alpha=0.2)
p.mesh3D(3, varx, vary, zdata, ptitle='Title', xlabel='x', ylabel='y', zlabel='z',
  rstride=3, cstride=3, linewidth= 0.2, maxNX=5, maxNY=5, maxNZ=0,
  drawGrid=True, cmap=cm.jet,  cbarshow=True, elevation=70, azimuth=15)
p.mesh3D(4, varx, vary, zdata, ptitle='Title', xlabel='x', ylabel='y', zlabel='z',
  rstride=3, cstride=3, linewidth= 0, maxNX=5, maxNY=5, maxNZ=0, drawGrid=True,
  cmap=cm.brg, cbarshow=True)


p.saveFig('mesh3d01.png')

print('done')
