Data from 

@MISC{Vasileska2010,
  author = {Dragica Vasileska},
  title = {Physical and Mathematical Description of the Operation of Photodetectors},
  year = {2010},
  url = {{\footnotesize{\url{http://nanohub.org/resources/9142}}}}
}



@BOOK{Piprek2003,
  title = {{Semiconductor Optroelectronic Devices}},
  publisher = {Academic Press},
  year = {2003},
  author = {Joachim Piprek}
}
