import numpy 

def fixDimensions(func):
  def inner(spectral, temperature):
    teppIn = numpy.array(temperature, copy=False,  ndmin=1)
    specIn = numpy.array(spectral, copy=False,  ndmin=1)

    #create flattened version of the input dataset
    specgrid, tempgrid = numpy.meshgrid(specIn,tempIn)
    spec = numpy.ravel(specgrid)
    temp = numpy.ravel(tempgrid)

    planckA = func(spec,temp) #2

    #now unflatten to proper structure again, spectral along axis=0
    if tempIn.shape[0] == 1 and specIn.shape[0] == 1:
        rtnVal = planckA[0]
    elif tempIn.shape[0] == 1 and specIn.shape[0] != 1:
        rtnVal = planckA.reshape(specIn.shape[0],)
    elif tempIn.shape[0] != 1 and specIn.shape[0] == 1:
        rtnVal = planckA.reshape(specIn.shape[0],-1)
    else:
        rtnVal = planckA.reshape(tempIn.shape[0],-1).T

    return rtnVal
  return inner

################################################################
##
@fixDimensions
def planckel(wavelength, temperature):
    """ Planck function in wavelength for radiant exitance.

    Args:
        | wavelength (np.array[N,]):  wavelength vector in  [um]
        | temperature (scalar, list[M], np.array[M,]):  Temperature in [K]

    Returns:
        | (scalar, np.array[N,M]):  spectral radiant exitance in W/(m^2.um)

    Raises:
        | No exception is raised.
    """
    # planckA = pconst.c1el / (spec ** 5 * ( numpy.exp(pconst.c2l / (spec * temp))-1));

    #test value of exponent to prevent infinity, force to exponent to zero
    #this happens for low temperatures and short wavelengths
    exP =  pconst.c2l / (spec * temp)
    exP2 = numpy.where(exP<explimit, exP, 1);
    p = (pconst.c1el / ( numpy.exp(exP2)-1)) / (spec ** 5)
    #if exponent is exP>=explimit, force Planck to zero
    planckA = numpy.where(exP<explimit, p, 0);

    return rtnVal


wl = numpy.linspace(1, 14, 101)
tp = numpy.asarray([100, 200, 300]).reshape(1,-1)

rtn = planckel(wl,tp)

print(rtns.shape)




