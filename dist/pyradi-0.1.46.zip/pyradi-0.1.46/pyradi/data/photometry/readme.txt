The photopic and scotopic data in this directory was downloaded from 
http://www.cvrl.org/index.htm

scvle.csv: CIE (1951) Scotopic V'(lambda)

vljve.csv: CIE Photopic V(lambda) modified by Judd (1951) and Vos (1978) [also known as CIE VM(lambda)] 

For more data files on colour and vision
http://www.cvrl.org/index.htm

