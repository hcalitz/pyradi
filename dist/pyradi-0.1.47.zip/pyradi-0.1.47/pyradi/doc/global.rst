.. |pyradilogo| image:: _images/pyradi.png
