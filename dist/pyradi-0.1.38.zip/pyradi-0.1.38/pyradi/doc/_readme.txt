To build the html documentation open a command window in this directory
and execute the command "make html".

To build the pdf documentation open a command window in this directory
and execute the command "make latex", and then build the pdf from the latex
files in pyradi/doc/_build/latex.

Building the documentation requires the sphinx documentation toolset.

