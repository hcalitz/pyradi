Utility Functions
******************

.. include global.rst

Overview
----------
.. automodule:: pyradi.ryutils

Module functions
------------------

.. autofunction:: pyradi.ryutils.abshumidity

.. autofunction:: pyradi.ryutils.sfilter

.. autofunction:: pyradi.ryutils.responsivity

.. autofunction:: pyradi.ryutils.effectiveValue

.. autofunction:: pyradi.ryutils.convertSpectralDomain

.. autofunction:: pyradi.ryutils.convertSpectralDensity

.. autofunction:: pyradi.ryutils.convolve

.. autofunction:: pyradi.ryutils.rangeEquation

.. autofunction:: pyradi.ryutils.detectThresholdToNoise

.. autofunction:: pyradi.ryutils.detectSignalToNoise

