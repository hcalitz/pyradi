import numpy as np
import urllib2
import pyradi.ryfiles as ryfiles


#url = 'https://pyradi.googlecode.com/svn/trunk/pyradi/' + \
#       'data/colourcoordinates/samplesVis.txt'
#if ryfiles.downloadFileUrl(url) is not None:
#    print('success')
#else:
#    print('download failed')

if ryfiles.unzipGZipfile('./data/colourcoordinates/tt/colourcoordinates.tgz','tar') is not None:
    print('success')
else:
    print('download failed')


result = ryfiles.untarTarfile('tar','.')
if result is not None:
    print(result)
else:
    print('untarTarfile failed')







                             

                             
                             
                             