lst = ['gg']
strn = 'gg'

if type(lst) == type([1]):
  print('GGGGG')


print(type(lst), type(strn))

